<?php  
session_start();  
  
if(!$_SESSION['admin_name'])  
{  
  
    header("Location: index.php");//redirect to login page to secure the welcome page without login access.  
}  
  
?> 

<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->
    <title>Add Info</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
    <h1 align="center">Add Info</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->

	<form action="addinfo.php" method="POST">
    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed;width:80%;">
      

	 <tr><td width="15%">Title </td><td><input type="text" name="title" required style="width:500px;"></td></tr>
	 <tr><td>URL </td><td><input type="text" name="url" style="width:500px;"></td></tr>
	 <tr><td>Username </td><td><input type="text" name="username" style="width:500px;"></td></tr>
	 <tr><td>Password </td><td><input type="text" name="password" style="width:500px;"></td></tr>
     <tr><td>Description </td><td><textarea name="description" cols="150" rows="20"> </textarea></td></tr>
	 <tr><td>Reference </td><td><input type="text" name="reference" style="width:500px;"></td></tr>
	 <tr><td> </td><td><input type="submit" style="float:left;margin-right:10px;" name="submit" class="btn btn-primary" value="Submit">
	 <div><a href="searchinfo.php" class="btn btn-warning">Cancel</a></div>
	 </td></tr>

    </table>
	</form>
        </div>
</div>


</body>

</html>
 <?php
	if(isset($_POST['submit']) && $_POST['title']!=NULL){
        include("database/db_conection.php");
        $query="INSERT INTO task (title,url,username,password,description,reference,date) VALUES('".mysql_real_escape_string($_POST['title'])."','".mysql_real_escape_string($_POST['url'])."','".mysql_real_escape_string($_POST['username'])."','".mysql_real_escape_string($_POST['password'])."','".mysql_real_escape_string($_POST['description'])."','".mysql_real_escape_string($_POST['reference'])."',NOW())";//select query for viewing users.
        $run=mysqli_query($dbcon,$query);//here run the sql query.
		if($run){
				header("Location:searchinfo.php?status=success");
		}else{
			echo "Could not save Record!";
		}

	}
        ?>
		
		<br>
		<br>