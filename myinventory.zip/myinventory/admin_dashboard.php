<?php
session_start();


?>

<html>
<head>

    <title>
        Registration
    </title>
</head>

<body>
<h1>Welcome</h1><br>

<h1><a href="searchinfo.php">Search info</a> </h1>
<h1><a href="logout.php">Logout here</a> </h1>


</body>

</html>

