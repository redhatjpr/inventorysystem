<?php  
session_start();  
  
if(!$_SESSION['admin_name'])  
{  
  
    header("Location: index.php");//redirect to login page to secure the welcome page without login access.  
}  
  
?> 

<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->
    <title>Search Info</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
    <h1 align="center">Search Info</h1>
	<div style="text-align:right;margin-right:50px;"><a href="logout.php" class="btn btn-primary">Logout</a></div>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->

	<center><form name="searchinfo" method="POST" action="searchinfo.php"> <input type="text" name="searchinput" value=""><input type="submit"  name="submit" value="Go"></form> </center>
	<div style="text-align:right;margin-right:290px;"><a href="addinfo.php" class="btn btn-primary">Add Info</a></div>
	
	

	<?php 
	
		if(isset($_POST['submit']) && $_POST['searchinput']!=NULL){
	?>
    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th width="20%">Title</th>
            <th width="20%">URL</th>
            <th>Username</th>
			<th>Password</th>
			<th>Description</th>
			<th>Action</th>
      
        </tr>
        </thead>

        <?php
	
        include("database/db_conection.php");
        $query="select * from task WHERE title like '%".$_POST['searchinput']."%' OR url like '%".$_POST['searchinput']."%' OR username like '%".$_POST['searchinput']."%' OR password like '%".$_POST['searchinput']."%' OR description like '%".$_POST['searchinput']."%' OR reference like '%".$_POST['searchinput']."%' ";//select query for viewing users.
        $run=mysqli_query($dbcon,$query);//here run the sql query.
		if($run->num_rows)
		{
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
			
            $title=$row[1];
            $url=$row[2];
            $username=$row[3];
			$password=$row[4];
			$description=$row[5];



        ?>

        <tr>
<!--here showing results in the table -->
            <td><?php echo $title;  ?></td>
			<td><?php echo $url;  ?></td>
            <td><?php echo $username; ?></td>
            <td><?php echo $password;  ?></td>
            <td><?php echo substr($description, 0, 200);  ?></td>
			<td><a href="viewinfo.php?infoid=<?php echo $row[0] ?>"><button class="btn btn-primary">View</button></a>
			<a href="delete.php?infoid=<?php echo $row[0] ?>"><button onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete</button></a></td>
        </tr>

        <?php }
		}else{
		?>
			<p style="color:red;">No Records Found...</p>
		<?php }?>
    </table>
		<?php } else{?>
			<center><p style="color:red;">Please enter something to search</p></center>
		<?php }?>
        </div>
</div>


</body>

</html>


<?php 
if(isset($_REQUEST['status'])){
	echo "<div style='color:green;'><center>Record has been saved successfully</center></div>";
}

?>