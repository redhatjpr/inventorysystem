<?php  
session_start();  
  
if(!$_SESSION['admin_name'])  
{  
  
    header("Location: index.php");//redirect to login page to secure the welcome page without login access.  
}  
  
?> 

<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->
    <title>View Info</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
    <h1 align="center">View Info</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
      
     <?php
	
	  include("database/db_conection.php");
        $query="select * from task WHERE id=".$_REQUEST['infoid'];//select query for viewing users.
        $run=mysqli_query($dbcon,$query);//here run the sql query.

        $row=mysqli_fetch_array($run); //while look to fetch the result and store in a array $row.
 
        ?>

	 <tr><td width="10%">Title </td><td><?php echo $row[1]?></td></tr>
     <tr><td>URL </td><td><a target="_blank" href="<?php echo $row[2]?>"><?php echo $row[2]?></a></td></tr>
	 <tr><td>username </td><td><?php echo $row[3]?></td></tr>
	 <tr><td>Password </td><td><?php echo $row[4]?></td></tr>
	 <tr><td>Description </td><td><?php echo nl2br($row[5])?></td></tr>
	 <tr><td>Reference </td><td><?php echo nl2br($row[6])?></td></tr>
	 <tr><td>Date and Time </td><td><?php echo date('d-M-Y g:i A', strtotime($row[7]));?></td></tr>

    </table>
	<div><a href="searchinfo.php" class="btn btn-warning">Cancel</a></div>
        </div>
</div>


</body>

</html>
